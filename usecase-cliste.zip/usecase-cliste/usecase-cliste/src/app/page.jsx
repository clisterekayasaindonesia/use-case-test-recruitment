"use client";

import { useEffect, useRef } from "react";
import { motion } from "framer-motion";
import { ChevronRight, Mail, Code, Database } from "lucide-react";

export default function Home() {
    const containerRef = useRef(null);

    useEffect(() => {
        const handleScroll = () => {
            const scrollY = window.scrollY;
            const sections = document.querySelectorAll(".animate-section");

            sections.forEach((section) => {
                const sectionTop = section.offsetTop - window.innerHeight * 0.75;
                if (scrollY > sectionTop) {
                    section.classList.add("animate-visible");
                }
            });
        };

        window.addEventListener("scroll", handleScroll);
        handleScroll();

        return () => window.removeEventListener("scroll", handleScroll);
    }, []);

    const containerVariants = {
        hidden: { opacity: 0 },
        visible: {
            opacity: 1,
            transition: {
                duration: 0.5,
                staggerChildren: 0.2,
            },
        },
    };

    const itemVariants = {
        hidden: { y: 20, opacity: 0 },
        visible: {
            y: 0,
            opacity: 1,
            transition: { duration: 0.5 },
        },
    };

    const listItemVariants = {
        hidden: { x: -10, opacity: 0 },
        visible: {
            x: 0,
            opacity: 1,
            transition: { duration: 0.3 },
        },
    };

    return (
        <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 text-slate-800 overflow-hidden">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 sm:py-20">
                <motion.div ref={containerRef} className="space-y-16 md:space-y-24" variants={containerVariants} initial="hidden" animate="visible">
                    <motion.header className="flex justify-center items-center" variants={itemVariants}>
                        <div className="relative">
                            <h1 className="text-4xl md:text-5xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-slate-800 to-slate-600">
                                Use Case Cliste
                            </h1>
                            <div className="absolute -bottom-3 left-0 right-0 h-1 bg-gradient-to-r from-emerald-400 to-cyan-400 rounded-full"></div>
                        </div>
                    </motion.header>

                    <motion.div className="grid md:grid-cols-2 gap-10 md:gap-16" variants={itemVariants}>
                        <motion.div
                            className="animate-section"
                            variants={itemVariants}
                            whileHover={{ scale: 1.02 }}
                            transition={{ type: "spring", stiffness: 300 }}
                        >
                            <div className="bg-white rounded-xl shadow-sm hover:shadow-md transition-all duration-300 p-8 h-full border border-slate-100">
                                <div className="flex items-center mb-6">
                                    <div className="w-10 h-10 rounded-full bg-emerald-100 flex items-center justify-center mr-4">
                                        <Code className="w-5 h-5 text-emerald-600" />
                                    </div>
                                    <h2 className="text-2xl font-semibold text-slate-800">Front End:</h2>
                                </div>

                                <motion.ul className="space-y-4 pl-4">
                                    {[
                                        "Membuat tampilan halaman login",
                                        "Membuat tampilan halaman register",
                                        "Mengintegrasikan halaman login dan register dengan backend berdasarkan dokumentasi API",
                                    ].map((item, index) => (
                                        <motion.li
                                            key={index}
                                            className="flex items-start"
                                            variants={listItemVariants}
                                            custom={index}
                                            whileHover={{ x: 5 }}
                                        >
                                            <ChevronRight className="w-5 h-5 text-emerald-500 mt-0.5 mr-2 flex-shrink-0" />
                                            <span className="text-slate-700">{item}</span>
                                        </motion.li>
                                    ))}
                                </motion.ul>
                            </div>
                        </motion.div>

                        <motion.div
                            className="animate-section"
                            variants={itemVariants}
                            whileHover={{ scale: 1.02 }}
                            transition={{ type: "spring", stiffness: 300 }}
                        >
                            <div className="bg-white rounded-xl shadow-sm hover:shadow-md transition-all duration-300 p-8 h-full border border-slate-100">
                                <div className="flex items-center mb-6">
                                    <div className="w-10 h-10 rounded-full bg-cyan-100 flex items-center justify-center mr-4">
                                        <Database className="w-5 h-5 text-cyan-600" />
                                    </div>
                                    <h2 className="text-2xl font-semibold text-slate-800">Backend:</h2>
                                </div>

                                <motion.ul className="space-y-4 pl-4">
                                    {[
                                        "Membuat tabel JobVacancy di Microsoft SQL Server dengan kolom Id, Title, Department, Location, dan Description.",
                                        "Menyusun query SQL untuk membuat entri baru pada tabel JobVacancy (Create).",
                                        "Menyusun query SQL untuk mengambil daftar semua lowongan pekerjaan (Read).",
                                        "Menyusun query SQL untuk memperbarui data lowongan pekerjaan berdasarkan Id (Update).",
                                        "Menyusun query SQL untuk menghapus data lowongan pekerjaan berdasarkan Id (Delete).",
                                        "Menyimpan semua query dalam file dengan format .sql.",
                                        "Memasukkan beberapa data awal ke tabel JobVacancy.",
                                        "Melakukan backup database ke dalam file dengan format .bak.",
                                        "Mengirimkan file .sql dan .bak melalui email.",
                                    ].map((item, index) => (
                                        <motion.li
                                            key={index}
                                            className="flex items-start"
                                            variants={listItemVariants}
                                            custom={index}
                                            whileHover={{ x: 5 }}
                                        >
                                            <ChevronRight className="w-5 h-5 text-cyan-500 mt-0.5 mr-2 flex-shrink-0" />
                                            <span className="text-slate-700">{item}</span>
                                        </motion.li>
                                    ))}
                                </motion.ul>
                            </div>
                        </motion.div>
                    </motion.div>

                    <motion.div className="animate-section pt-8 border-t border-slate-200" variants={itemVariants}>
                        <div className="bg-gradient-to-r from-slate-800 to-slate-700 rounded-xl p-8 shadow-md">
                            <div className="flex flex-col md:flex-row items-center justify-center gap-4 text-white">
                                <Mail className="w-6 h-6 text-emerald-300" />
                                <p className="text-center text-lg">
                                    Kirim hasil yang kamu buat ke <span className="font-semibold text-emerald-300">office@cliste.co.id</span>, dengan
                                    format nama file "<span className="italic">[Nama Lengkap]_testCaseIntern</span>"
                                </p>
                            </div>
                        </div>
                    </motion.div>
                </motion.div>
            </div>
        </div>
    );
}
