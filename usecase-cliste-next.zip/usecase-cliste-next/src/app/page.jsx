import Image from "next/image";

export default function Home() {
    return (
        <div className="grid items-center justify-items-center min-h-screen sm:p-20 font-[family-name:var(--font-geist-sans)]">
            <div className="space-y-20 h-1/2">
                <header className=" flex justify-center items-center">
                    <h1 className="text-3xl font-bold">Use Case Cliste</h1>
                </header>
                <div className="flex justify-center items-start space-x-10">
                    <div className="w-1/2">
                        <h2 className="text-xl font-semibold">Front End :</h2>
                        <ul className="list-disc">
                            <li>Buat tampilan untuk login</li>
                            <li>Buat tampilan untuk Register</li>
                            <li>Integrasi halaman login dan register dengan backend yang kamu buat !!</li>
                        </ul>
                    </div>
                    <div className="flex-1 h-full">
                        <h2 className="text-xl font-semibold">Backend End :</h2>
                        <ul className="list-disc">
                            <li>Buat API untuk Autentikasi</li>
                            <li>Buat API untuk Login dan Register </li>
                        </ul>
                    </div>
                </div>
                <p className="text-center">Submit hasil perjuanganmu ke repo kami ya ! </p>
            </div>
        </div>
    );
}
